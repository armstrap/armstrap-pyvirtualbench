AVbin

Copyright 2007 Alex Holkner <Alex.Holkner@gmail.com>
AVbin incorporates FFmpeg, http://ffmpeg.mplayerhq.hu/

To install, copy avbin.dll to c:\Windows\System32.
